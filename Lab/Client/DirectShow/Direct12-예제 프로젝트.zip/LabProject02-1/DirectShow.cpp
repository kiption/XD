#include "stdafx.h"
#include "DirectShow.h"
#include <uuids.h>
#include <dshow.h>

int DirectShow::DirectShowCall()
{
    HRESULT hr = CoInitialize(NULL);
    if (FAILED(hr))
    {
        std::cout << "Failed to initialize COM library" << std::endl;
        return hr;
    }

    hr = MFStartup(MF_VERSION);
    if (FAILED(hr))
    {
        std::cout << "Failed to start Media Foundation" << std::endl;
        CoUninitialize();
        return hr;
    }

    IMFSourceResolver* pSourceResolver = NULL;
    hr = MFCreateSourceResolver(&pSourceResolver);
    if (FAILED(hr))
    {
        std::cout << "Failed to create Source Resolver" << std::endl;
        MFShutdown();
        CoUninitialize();
        return hr;
    }

    IMFMediaSource* pMediaSource = NULL;
    MF_OBJECT_TYPE ObjectType;
    WCHAR* pFilePath = L"C:/Users/PC/Desktop/Direct12 - ���� ������Ʈ/LabProject02 - 1/Opening/mest.mp4";
    DWORD cchFilePath = (DWORD)wcslen(pFilePath);
    hr = pSourceResolver->CreateObjectFromURL(pFilePath, MF_RESOLUTION_MEDIASOURCE, NULL, &ObjectType, (IUnknown**)&pMediaSource);
    if (FAILED(hr))
    {
        std::cout << "Failed to create Media Source" << std::endl;
        pSourceResolver->Release();
        MFShutdown();
        CoUninitialize();
        return hr;
    }

    IMFGetService* pGetService = NULL;
    IMFMediaSession* pMediaSession = NULL;
    hr = MFCreateMediaSession(NULL, &pMediaSession);
    if (FAILED(hr))
    {
        std::cout << "Failed to create Media Session" << std::endl;
        pMediaSource->Release();
        pSourceResolver->Release();
        MFShutdown();
        CoUninitialize();
        return hr;
    }

    IMFVideoDisplayControl* pVideoDisplayControl = NULL;
   hr = pMediaSession->QueryInterface(IID_PPV_ARGS(&pGetService));
   if (SUCCEEDED(hr))
   {
       IMFVideoDisplayControl* pVideoDisplayControl = NULL;
       hr = pGetService->GetService(MR_VIDEO_RENDER_SERVICE, IID_PPV_ARGS(&pVideoDisplayControl));
       pGetService->Release();


       if (FAILED(hr))
       {
           std::cout << "Failed to get Video Display Control" << std::endl;
           pMediaSession->Shutdown();
           pMediaSession->Release();
           pMediaSource->Release();
           pSourceResolver->Release();
           MFShutdown();
           CoUninitialize();
           return hr;
       }
   }
    hr = pMediaSession->SetTopology(0, NULL);
    if (FAILED(hr))
    {
        std::cout << "Failed to set topology" << std::endl;
        pVideoDisplayControl->Release();
        pMediaSession->Shutdown();
        pMediaSession->Release();
        pMediaSource->Release();
        pSourceResolver->Release();
        MFShutdown();
        CoUninitialize();
        return hr;
    }

    hr = pMediaSession->Start(NULL, NULL);
    if (FAILED(hr))
    {
        std::cout << "Failed to start playback" << std::endl;
        pVideoDisplayControl->Release();
        pMediaSession->Shutdown();
        pMediaSession->Release();
        pMediaSource->Release();
        pSourceResolver->Release();
        MFShutdown();
        CoUninitialize();
        return hr;
    }

    // Wait for playback to finish
    BOOL bDone = FALSE;
    while (!bDone)
    {
        IMFMediaEvent* pEvent = NULL;
        HRESULT hrStatus = pMediaSession->GetEvent(0, &pEvent);
        if (SUCCEEDED(hrStatus))
        {
            MediaEventType met;
            pEvent->GetType(&met);
            if (met == MESessionEnded)
            {
                bDone = TRUE;
            }
            pEvent->Release();
        }
    }

    pVideoDisplayControl->Release();
    pMediaSession->Shutdown();
    pMediaSession->Release();
    pMediaSource->Release();
    pSourceResolver->Release();
    MFShutdown();
    CoUninitialize();

    return 0;
}
