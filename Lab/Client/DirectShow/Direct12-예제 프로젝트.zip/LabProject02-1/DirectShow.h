#pragma once

class DirectShow
{
public:
	DirectShow() {}
	~DirectShow() {}
	int DirectShowCall();
};